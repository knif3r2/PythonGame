from classes import monsterlist

class Monster:
    def __init__(self, id):
        self.name = 't'