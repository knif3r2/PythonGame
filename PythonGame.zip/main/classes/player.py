import json

class Player:
    # Default Constructor of Player
    def __init__ (self, name):
        self.name = name
        self.hp = 10
        self.maxhp = 10
        self.posx = 5
        self.posy = 15
        self.exp_actual = 0
        self.exp_max = 10
        self.bagslots = 6

    def EquipItemCheck(self, itemid):
        with open('Files\Items.json') as json_string:
            data = json.load(json_string)
            item = data, object_hook=lambda: namedtuple('X', d.keys())(*d.values())
            print(item.name)
            json_string.close()

    # - Health Check
    # Checks the health of the player and determines
    # if the game is over
    def HealthCheck(self):
        if(self.hp <= 0):
            self.hp = 0
            print('HP %d/%d' % (self.hp, self.maxhp))
            print('Game Over!')
            del self
        else:
            print('HP %d/%d' % (self.hp, self.maxhp))
    
    # - Player Damage Manager
    # Controls how the player takes damage.
    def Monster_DMG(self, inc_dmg):
         self.hp =- inc_dmg
         Player.HealthCheck(self)

    #def Player_DMG(self, inc_dmg):
