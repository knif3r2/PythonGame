from classes.player import Player
import json

class Main:
    def main(self):
        name = input("Player Name: ")
        p = Player(name)

        with open('Files\Items.json') as json_data:
            data = json.load(json_data)
            item = data['ItemList'][0]['Weapon']['1H_Melee'][1]
            print(item)
            json_data.close()

Main().main()

